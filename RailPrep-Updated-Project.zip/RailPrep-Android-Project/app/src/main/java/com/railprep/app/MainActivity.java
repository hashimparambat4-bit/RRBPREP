package com.railprep.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new QuestionBridge(), "RailPrepBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class QuestionBridge {

        @JavascriptInterface
        public void openPdf() {
            runOnUiThread(() -> {
                try {
                    File pdf = new File(getCacheDir(), "8000-pyq-in-one-line.pdf");
                    if (!pdf.exists() || pdf.length() == 0) {
                        try (InputStream in = getAssets().open("8000-pyq-in-one-line.pdf"); FileOutputStream out = new FileOutputStream(pdf)) {
                            byte[] buffer = new byte[8192];
                            int count;
                            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                        }
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", pdf);
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(uri, "application/pdf");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(intent, "Open PYQ PDF"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Install a PDF viewer to open this file.", Toast.LENGTH_LONG).show();
                }
            });
        }


        @JavascriptInterface
        public void openSourcePdf(String assetName) {
            runOnUiThread(() -> {
                try {
                    String safeName = assetName == null ? "" : assetName.replace("..", "").replace("/", "").replace("\\", "");
                    String assetPath = safeName.equals("8000-pyq-in-one-line.pdf") ? safeName : "pdfs/" + safeName;
                    File pdf = new File(getCacheDir(), safeName);
                    if (!pdf.exists() || pdf.length() == 0) {
                        try (InputStream in = getAssets().open(assetPath); FileOutputStream out = new FileOutputStream(pdf)) {
                            byte[] buffer = new byte[8192]; int count;
                            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                        }
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", pdf);
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(uri, "application/pdf");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(intent, "Open RailPrep study PDF"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not open this PDF. Please install a PDF viewer.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public String getQuestionsJson() {
            try (InputStream in = getAssets().open("questions.json"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                return out.toString("UTF-8");
            } catch (Exception e) {
                return "[]";
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
