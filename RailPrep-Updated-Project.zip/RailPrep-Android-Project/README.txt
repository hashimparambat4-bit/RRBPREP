RailPrep Android project — Matcha/Sage update

This is a Gradle Android project using a WebView-based interface.

Design palette:
- Soft Matcha Cream #F5F6F1
- Deep Sage #2C4E3F
- Muted Mint #8FA89B
- Warm Ochre Gold #E5A93B
- Off-Black Charcoal #1C2421

Includes:
- Current 671-question JSON bank (500 GK questions sourced from the uploaded RRB GK PDF, plus 171 nursing practice questions).
- Eight PDF references in app assets (the seven uploaded source PDFs and the existing 8000-PYQ PDF).
- PDF Library UI, book-opening splash animation, light/dark theme, category-level retake, reset-all confirmation (including attempt history), saved attempt snapshots, bookmarks, progress and timed mock test.
- Android GitHub Actions workflow to build a debug APK.

Important content limitation:
The 500 GK questions are sourced from the uploaded GK PDF. The 171 nursing questions are a separate practice bank and have not yet been fully verified/imported verbatim from all nursing PDFs. The original PDFs are bundled for reference. Review question/answer accuracy before production release.

Build:
Run `gradle assembleDebug` in an environment with Android SDK installed, or use the included GitHub Actions workflow.
