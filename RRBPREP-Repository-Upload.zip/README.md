# RRBPREP / RailPrep Android repository

This repository is an Android WebView wrapper around the bundled RailPrep HTML app. The HTML is included locally at `app/src/main/assets/index.html`, so the app does not need to download the app UI at runtime.

## Build an APK using GitHub on an Android phone

1. Download and extract `RRBPREP-Repository-Upload.zip` on your phone.
2. Open your GitHub repository: `https://github.com/hashimparambat4-bit/RRBPREP`.
3. Add the project files/folders from this ZIP at the repository root. Preserve the `.github/workflows/android-apk.yml` path. If GitHub's mobile website cannot upload a whole folder, use the browser's **Desktop site** mode or GitHub's upload interface; folders beginning with a dot may need to be created through **Add file → Create new file** first.
4. Commit the files to the `main` branch (or `master`). A push automatically starts the workflow. You can also open **Actions → Build RailPrep Android APK → Run workflow**.
5. Open the completed workflow run, scroll to **Artifacts**, and download `RailPrep-debug-apk`. Extract that artifact ZIP to get `app-debug.apk`.
6. Tap `app-debug.apk` on your phone to install it. Android may ask you to allow app installs from the browser or file manager you used.

## Repository layout

- `app/src/main/assets/index.html` — bundled RailPrep web app.
- `app/src/main/java/com/railprep/app/MainActivity.java` — Android WebView activity.
- `app/src/main/AndroidManifest.xml` — Android app declaration.
- `app/build.gradle` and root Gradle files — Android build configuration.
- `.github/workflows/android-apk.yml` — GitHub Actions workflow that builds and uploads a debug APK.

## Important

This is project source, not a prebuilt APK. The workflow must run successfully before an APK artifact exists. Test navigation, settings, themes, PDF viewing, and back-button behavior on the actual phone before relying on it. A debug APK is for personal testing; public release needs release signing and further testing.
