RailPrep Android APK project

IMPORTANT: This ZIP is arranged so that its contents belong directly in the ROOT of your GitHub repository. Do not upload the ZIP as a single file and expect GitHub Actions to extract it.

Expected repository root:
  .github/workflows/android.yml
  app/build.gradle
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/railprep/app/MainActivity.java
  app/src/main/assets/index.html
  app/src/main/assets/questions.json
  build.gradle
  settings.gradle
  gradle.properties

Using a phone:
1. Download this ZIP and extract it with your phone's Files app.
2. In GitHub, open your RRBPREP repository.
3. Upload the extracted project files/folders to the repository root, preserving the folder structure. Make sure the hidden .github folder is included. If GitHub's web uploader cannot upload a folder, use a Git client or upload the files/folders individually while preserving paths.
4. Replace the existing .github/workflows/android.yml with the one from this ZIP.
5. Commit the changes to the main branch.
6. Open Actions > Build RailPrep APK. If it did not start automatically, choose Run workflow.
7. When the run succeeds, open the run and download the RailPrep-debug-apk artifact.

Do not put the project inside an extra RailPrep-Android folder in the repository. The settings.gradle file and app folder must be directly in the repository root.

Included PDF: 8000-pyq-in-one-line.pdf. Use the Open 8000 PYQ PDF button in Study tools. Dark mode can be toggled from the top bar and is saved on this device.
