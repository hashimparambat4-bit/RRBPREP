# RailPrep Android project

This Android Studio project wraps the current RailPrep theme-fix HTML in a native Android WebView. It bundles the HTML and its embedded PDFs locally, so it does not need a separate HTML file or internet connection for the bundled content.

## Build an APK
1. Install Android Studio on a computer and let it install Android SDK Platform 35 and a compatible Android Gradle Plugin/Gradle version.
2. Open this `RailPrep-Android-Project` folder in Android Studio.
3. Wait for Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`). Transfer that APK to your Android phone and install it. If prompted, allow installation from that source.

## Notes
- This package is an Android Studio source project, not a precompiled APK. The current execution environment does not have the Android SDK/Gradle toolchain required to compile and sign an APK here.
- The app uses a local WebView and enables JavaScript/DOM storage for the app's interactive features.
- External website navigation is intentionally blocked inside the WebView. Bundled PDFs are embedded in the HTML app.
- This is a debug-build starting point; for public release, add a production signing key and test the app thoroughly on target devices.
